package com.example.modul5kel12.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.modul5kel12.Model.DataBarang;
import com.example.modul5kel12.R;

import java.util.List;

public class BarangAdapter extends RecyclerView.Adapter<BarangViewHolder> {
    private List<DataBarang> dataBarangs;
    private BarangListener barangListener;

    public BarangAdapter(List<DataBarang> dataBarangs){
        this.dataBarangs = dataBarangs;
    }

    public void setAdapterListener(BarangListener barangListener){
        this.barangListener = barangListener;
    }

    @NonNull
    @Override
    public BarangViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.item_barang, parent, false);
        return new BarangViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BarangViewHolder holder, int position) {
        DataBarang dataUser = get(position);
        holder.bind(dataUser, barangListener);
    }

    private DataBarang get(int position) {
        return dataBarangs.get(position);
    }

    @Override
    public int getItemCount() {
        if (dataBarangs == null) return 0;
        return dataBarangs.size();
    }
}
