package com.example.modul5kel12.View;

public interface AddView {
    String getNama();

    String getHarga();

    String getStok();

    void successAddBarang();

    void failedAddBarang();
}