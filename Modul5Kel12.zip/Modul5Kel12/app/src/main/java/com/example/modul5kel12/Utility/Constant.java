package com.example.modul5kel12.Utility;

public class Constant {
    public static final String BASE_URL = "https://praktikummdp12019.000webhostapp.com/api/";

    public final class Extra {
        public static final String DATA = "EXTRA_DATA";
    }
}