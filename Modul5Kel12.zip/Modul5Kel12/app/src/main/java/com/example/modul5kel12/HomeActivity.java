package com.example.modul5kel12;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.modul5kel12.Adapter.BarangAdapter;
import com.example.modul5kel12.Adapter.BarangListener;
import com.example.modul5kel12.Model.DataBarang;
import com.example.modul5kel12.Presenter.HomePresenter;
import com.example.modul5kel12.View.HomeView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class HomeActivity extends AppCompatActivity implements HomeView, BarangListener {

    private HomePresenter homePresenter;
    private BarangAdapter barangAdapter;
    FloatingActionButton fabHome;
    RecyclerView rvHome;
    SwipeRefreshLayout srlHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initPresenter();
        initView();
        initDataPresenter();

        addBarang();
        refresh();
    }

    private void initView() {
        fabHome = findViewById(R.id.fabHome);
        rvHome = findViewById(R.id.rvHome);
        srlHome = findViewById(R.id.srlHome);
    }

    private void initPresenter() {
        homePresenter = new HomePresenter((HomeView) this);
    }

    private void initDataPresenter() {
        homePresenter.getAllBarang();
    }

    private void addBarang() {
        fabHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addBarang = new Intent(HomeActivity.this, AddActivity.class);
                HomeActivity.this.startActivity(addBarang);
                HomeActivity.this.finish();
            }
        });
    }

    private void refresh(){
        srlHome.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                HomeActivity.this.initDataPresenter();
            }
        });
    }

    @Override
    public void successShowBarang(List<DataBarang> dataBarangs) {
        if (srlHome.isRefreshing()){
            srlHome.setRefreshing(false);
        }
        barangAdapter = new BarangAdapter(dataBarangs);
        barangAdapter.setAdapterListener((BarangListener) this);
        rvHome.setLayoutManager(new LinearLayoutManager(this));
        rvHome.setAdapter(barangAdapter);
    }

    @Override
    public void failedShowBarang(String message) {
        Toast.makeText(this, "Maaf terjadi kesalahan", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBarangClick(DataBarang dataBarang) {
        //Intent intent = new Intent(this, DetailActivity.class);
        //intent.putExtra(Constant.Extra.DATA, dataBarang);
        //startActivity(intent);
    }
}