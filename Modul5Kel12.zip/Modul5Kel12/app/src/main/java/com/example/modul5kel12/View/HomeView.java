package com.example.modul5kel12.View;

import com.example.modul5kel12.Model.DataBarang;

import java.util.List;

public interface HomeView {
    void successShowBarang(List<DataBarang> dataBarangs);
    void failedShowBarang(String message);
}