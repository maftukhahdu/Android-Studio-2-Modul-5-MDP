package com.example.modul5kel12.Adapter;

import com.example.modul5kel12.Model.DataBarang;

public interface BarangListener {
    void onBarangClick(DataBarang dataBarang);
}