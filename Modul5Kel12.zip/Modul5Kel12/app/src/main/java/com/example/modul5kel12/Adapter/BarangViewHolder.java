package com.example.modul5kel12.Adapter;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.modul5kel12.Model.DataBarang;
import com.example.modul5kel12.R;

public class BarangViewHolder extends RecyclerView.ViewHolder {
    LinearLayout linearLayout;
    TextView tvNama, tvHarga, tvStok;

    public BarangViewHolder(@NonNull View itemView) {
        super(itemView);
        initView(itemView);
    }

    private void initView(View itemView) {
        linearLayout = itemView.findViewById(R.id.linear_item);
        tvNama = itemView.findViewById(R.id.tvNama);
        tvHarga = itemView.findViewById(R.id.tvHarga);
        tvStok = itemView.findViewById(R.id.tvStok);
    }

    public void bind(final DataBarang dataBarang, final BarangListener barangListener) {
        tvNama.setText(dataBarang.getNama());
        tvHarga.setText(dataBarang.getHarga());
        tvStok.setText(dataBarang.getStok());

        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                barangListener.onBarangClick(dataBarang);
            }
        });
    }
}
